package lab3.rooms;

import lab3.descriptions.WindowType;

public interface WindowInterface {
    public WindowType getWindowType();
}
