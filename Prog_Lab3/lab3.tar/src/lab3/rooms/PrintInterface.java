package lab3.rooms;

public interface PrintInterface {
    public void print();
}
