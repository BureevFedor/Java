package lab3.rooms;

import lab3.descriptions.WallType;

public interface WallInterface {
    public WallType getWallType();
}
