package lab3.rooms;

import lab3.descriptions.BridgeType;

public interface BridgeInterface {
    public BridgeType getType();
}
