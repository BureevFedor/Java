package lab3.rooms;

import lab3.descriptions.FloorType;

public interface FloorInterface {
    public FloorType getFloorType();
}
